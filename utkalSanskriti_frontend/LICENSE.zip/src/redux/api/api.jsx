import axios from 'axios';

// Base API URL
const API_URL = 'http://localhost:8080'; // Update with actual API URL

// Create Axios instance
const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Attach Authorization token
api.interceptors.request.use(
  (config) => {
    const token = sessionStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// GET Request
export const getData = async (endpoint) => {
  try {
    const response = await api.get(endpoint);
    return response.data;
  } catch (error) {
    throw error.response?.data || { message: error.message };
  }
};

// POST Request
export const postData = async (endpoint, data) => {
  try {
    const response = await api.post(endpoint, data);
    return response.data;
  } catch (error) {
    throw error.response?.data || { message: error.message };
  }
};

// PUT Request
export const putData = async (endpoint, data) => {
  try {
    const response = await api.put(endpoint, data);
    return response.data;
  } catch (error) {
    throw error.response?.data || { message: error.message };
  }
};

// DELETE Request
export const deleteData = async (endpoint) => {
  try {
    await api.delete(endpoint);
  } catch (error) {
    throw error.response?.data || { message: error.message };
  }
};

export default api;
