import { createSlice } from '@reduxjs/toolkit';
import { loginUser } from '../thunks/authThunks';

// Check sessionStorage for token and role during initial load
const initialState = {
  user: null,
  role: sessionStorage.getItem('role') || null, // Check for stored role
  status: 'idle',
  error: null,
};

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(loginUser.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(loginUser.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.user = action.payload;

        const token = action.payload.token;
        sessionStorage.setItem('token', token);

        const decodedToken = decodeJWT(token);
        state.role = decodedToken.role;

        // Store the role in sessionStorage for future reference
        if (state.role) {
          sessionStorage.setItem('role', state.role);
        }
      })
      .addCase(loginUser.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload;
      });
  },
});

function decodeJWT(token) {
  const base64Url = token.split('.')[1]; 
  const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
  const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
    return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
  }).join(''));

  return JSON.parse(jsonPayload);
}

export default authSlice.reducer;
