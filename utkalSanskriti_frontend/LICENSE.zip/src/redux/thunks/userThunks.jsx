import { createAsyncThunk } from '@reduxjs/toolkit';
import { getData, postData, putData, deleteData } from '../api/api';

// Fetch User Data (GET)
export const fetchUserData = createAsyncThunk(
  'user/fetchUserData',
  async (_, { rejectWithValue }) => {
    try {
      const data = await getData(`/api/auth/user-details`);
      return data;
    } catch (error) {
      return rejectWithValue(error.response?.data || { message: error.message });
    }
  }
);

// Create User (POST)
export const createUser = createAsyncThunk(
  'user/createUser',
  async (userData, { dispatch, rejectWithValue }) => {
    try {
      const data = await postData(`/api/auth/register`, userData);
      // Dispatch fetchUserData to reload users after successfully creating a new user
      dispatch(fetchUserData()); // This triggers fetching the user list again
      return data;
    } catch (error) {
      return rejectWithValue(error.response?.data || { message: error.message });
    }
  }
);

// Update User (PUT)
export const updateUser = createAsyncThunk(
  'user/updateUser',
  async ({ userId, userData }, { rejectWithValue }) => {
    try {
      const data = await putData(`/api/users/${userId}`, userData);
      return data;
    } catch (error) {
      return rejectWithValue(error.response?.data || { message: error.message });
    }
  }
);

// Delete User (DELETE)
export const deleteUser = createAsyncThunk(
  'user/deleteUser',
  async (userId, { rejectWithValue }) => {
    try {
      await deleteData(`/api/users/${userId}`);
      return userId;
    } catch (error) {
      return rejectWithValue(error.response?.data || { message: error.message });
    }
  }
);
