import { configureStore } from '@reduxjs/toolkit';
import userReducer from './slices/userSlice';
import authReducer from './slices/authSlice'; // Add authReducer here

const store = configureStore({
  reducer: {
    user: userReducer, // User-related slice
    auth: authReducer,  // Auth-related slice
  },
});

export default store;
