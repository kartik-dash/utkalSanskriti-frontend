import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import AdminLayout from './layouts/AdminLayout';
import ClientLayout from './layouts/ClientLayout';
import Top_Level_ManagementLayout from './layouts/Top_Level_ManagementLayout';
import Mid_Level_ManagementLayout from './layouts/Mid_Level_ManagementLayout';
import Low_Level_ManagementLayout from './layouts/Low_Level_ManagementLayout';
import Executive_ManagementLayout from './layouts/Executive_ManagementLayout';
import UserLayout from './layouts/UserLayout';
import { useSelector } from "react-redux";
import Signin from './pages/Login';  // Assuming this is your Home page

const App = () => {
  const [userRole, setUserRole] = useState(null); // Initialize userRole state
  const { role } = useSelector((state) => state.auth);
  useEffect(() => {
    const role = sessionStorage.getItem('role');
    setUserRole(role);
  }, []); // Run once on mount to get the role from sessionStorage

  return (
    <Router>
      <div className="min-h-screen bg-gray-100">
        <Routes>
          {/* Conditional Route rendering based on user role */}
          {role === 'MASTER_ADMIN' && <Route path="*" element={<AdminLayout />} />}
          {role === 'USER' && <Route path="*" element={<ClientLayout />} />}
          {role === 'TOP_LEVEL_MANAGEMENT' && <Route path="*" element={<Top_Level_ManagementLayout />} />}
          {role === 'MID_LEVEL_MANAGEMENT' && <Route path="*" element={<Mid_Level_ManagementLayout />} />}
          {role === 'LOWER_LEVEL_MANAGEMENT' && <Route path="*" element={<Low_Level_ManagementLayout />} />}
          {role === 'EXUCUTIVE_MANAGEMENT' && <Route path="*" element={<Executive_ManagementLayout />} />}
          {/* {role === 'user' && <Route path="*" element={<UserLayout />} />} */}
          
          {/* Default route for public-facing pages */}
          <Route path="/" element={<Signin />} />
          <Route path="/login" element={<Signin />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
