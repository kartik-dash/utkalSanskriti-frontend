import React from "react";
import body from "../../src/assets/img/body.jpg";

export default function Home() {
  return (
    <>
      <div className="relative">
        <img src={body} alt="hero-body" className="w-full h-[800px] " />
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center text-black">
          <h1 className="text-8xl font-bold">Explore Odisha</h1>
          <p className="text-4xl mt-4">Plan better with 300,000+ travel experiences</p>
        </div>
      </div>
      <div className="py-16 px-4 text-center">
        <h2 className="text-3xl font-semibold mb-4">Why Choose Jay Jagannath?</h2>
        <p className="text-lg mb-8">
          Discover the best travel experiences and services with Jay Jagannath. Here’s why we stand out:
        </p>

        {/* Optional List of Reasons */}
        <ul className="space-y-4 text-left max-w-4xl mx-auto">
          <li className="flex items-center space-x-2">
            <span className="text-xl text-green-500">✔</span>
            <p className="text-lg">Comprehensive travel planning and expert advice.</p>
          </li>
          <li className="flex items-center space-x-2">
            <span className="text-xl text-green-500">✔</span>
            <p className="text-lg">Access to over 300,000 verified travel experiences.</p>
          </li>
          <li className="flex items-center space-x-2">
            <span className="text-xl text-green-500">✔</span>
            <p className="text-lg">Customizable travel itineraries tailored to your needs.</p>
          </li>
          <li className="flex items-center space-x-2">
            <span className="text-xl text-green-500">✔</span>
            <p className="text-lg">24/7 customer support to assist you throughout your journey.</p>
          </li>
        </ul>
      </div>
    </>
  );
}
