import { useState } from "react";
import { Bar } from "react-chartjs-2"; // Importing Bar chart from react-chartjs-2
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from "chart.js"; // Import necessary chart.js components
import { format, startOfWeek, parseISO } from "date-fns"; // Import date-fns to format and parse dates
import { PieChart, Pie, Cell, ResponsiveContainer, Legend as RechartsLegend } from "recharts"; // Import PieChart from recharts

// Register the necessary chart.js components
ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const reports = [
  { id: 1, type: "User", date: "2025-01-10", status: "Completed" },
  { id: 2, type: "Sales", date: "2025-01-12", status: "Pending" },
  { id: 3, type: "System", date: "2025-02-05", status: "Completed" },
  { id: 4, type: "User", date: "2025-01-25", status: "Pending" },
  { id: 5, type: "Sales", date: "2025-02-01", status: "Completed" },
];

export default function ReportManagement() {
  const [filteredReports, setFilteredReports] = useState(reports);
  const [reportType, setReportType] = useState("user");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  const filterReports = () => {
    const filtered = reports.filter((report) => {
      const isTypeMatch = report.type.toLowerCase() === reportType.toLowerCase();
      const isDateInRange =
        (!startDate || report.date >= startDate) &&
        (!endDate || report.date <= endDate);
      return isTypeMatch && isDateInRange;
    });
    setFilteredReports(filtered);
  };
  const getStatusClass = (status) => {
    switch (status) {
      case "Completed":
        return "text-green-500";
      case "Pending":
        return "text-yellow-500";
      default:
        return "text-gray-500";
    }
  };
  // Group reports by week, and get status counts for each day of the week
  const groupReportsByWeek = () => {
    const groupedData = {};

    filteredReports.forEach((report) => {
      const weekStart = format(startOfWeek(parseISO(report.date)), 'yyyy-MM-dd'); // Get the start of the week
      const dayOfWeek = format(parseISO(report.date), 'EEEE'); // Get the day name (e.g., Monday, Tuesday)

      if (!groupedData[weekStart]) {
        groupedData[weekStart] = { "Under Progress": {}, Error: {}, Pending: {}, Completed: {} };
      }

      // Initialize the count for the day if not exists
      if (!groupedData[weekStart][report.status][dayOfWeek]) {
        groupedData[weekStart][report.status][dayOfWeek] = 0;
      }

      // Increment the count for the status on that specific day
      groupedData[weekStart][report.status][dayOfWeek]++;
    });

    return groupedData;
  };

  // Prepare data for the chart
  const prepareChartData = () => {
    const groupedData = groupReportsByWeek();
    const labels = [];
    const underProgressData = [];
    const errorData = [];
    const pendingData = [];
    const completedData = [];

    Object.keys(groupedData).forEach((weekStart) => {
      labels.push(weekStart);

      const weekData = groupedData[weekStart];

      underProgressData.push(weekData["Under Progress"] ? Object.values(weekData["Under Progress"]).reduce((a, b) => a + b, 0) : 0);
      errorData.push(weekData.Error ? Object.values(weekData.Error).reduce((a, b) => a + b, 0) : 0);
      pendingData.push(weekData.Pending ? Object.values(weekData.Pending).reduce((a, b) => a + b, 0) : 0);
      completedData.push(weekData.Completed ? Object.values(weekData.Completed).reduce((a, b) => a + b, 0) : 0);
    });

    return {
      labels: labels,
      datasets: [
        {
          label: "Under Progress",
          data: underProgressData,
          backgroundColor: "#FFC107",
        },
        {
          label: "Error",
          data: errorData,
          backgroundColor: "#FF0000", // Red color for errors
        },
        {
          label: "Pending",
          data: pendingData,
          backgroundColor: "#FFEB3B",
        },
        {
          label: "Completed",
          data: completedData,
          backgroundColor: "#4CAF50",
        },
      ],
    };
  };

  const chartOptions = {
    responsive: true,
    scales: {
      y: {
        beginAtZero: true,  // Ensure the scale starts from zero
        ticks: {
          stepSize: 1, // Adjust step size if needed
        },
      },
    },
  };

  // Calculate counts for each status
  const statusCounts = filteredReports.reduce(
    (acc, report) => {
      acc[report.status] = (acc[report.status] || 0) + 1;
      return acc;
    },
    { "Under Progress": 0, Error: 0, Pending: 0, Completed: 0 }
  );

  // Convert counts to percentages, ensuring that no division by zero occurs
  const totalReports = filteredReports.length;
  const pieData = Object.keys(statusCounts).map((status) => ({
    name: status,
    value: totalReports > 0 ? (statusCounts[status] / totalReports) * 100 : 0, // Ensure safe percentage calculation
  }));

  const COLORS = ["#FFC107", "#FF0000", "#FFEB3B", "#4CAF50"]; // Colors for Under Progress, Error, Pending, Completed

  return (
    <div className="flex h-screen">
      <div className="flex-grow p-6">
        <h1 className="text-center text-2xl font-bold">Manage Reports</h1>
        <div className="my-4 flex gap-4">
          <select
            value={reportType}
            onChange={(e) => setReportType(e.target.value)}
            className="p-2 border rounded"
          >
            <option value="user">User Reports</option>
            <option value="sales">Sales Reports</option>
            <option value="system">System Reports</option>
          </select>
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="p-2 border rounded"
          />
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="p-2 border rounded"
          />
          <button
            onClick={filterReports}
            className="p-2 bg-green-600 text-white rounded hover:bg-green-700"
          >
            Filter Reports
          </button>
        </div>

        <div className="status_distribution" style={{ display: "flex" }}>

          {/* Display the chart */}
          <div className="my-6" style={{ height: '70%', width: '70%' }}>
            <Bar data={prepareChartData()} options={chartOptions} />
          </div>

          <div className="chart_userpie_status_distribution">
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-xl font-medium mb-4">Report Status Distribution</h3>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={pieData}
                    dataKey="value"
                    nameKey="name"
                    outerRadius={120}
                    fill="#8884d8"
                    label={({ name, percent }) => {
                      return `${name}: ${(percent * 100).toFixed(2)}%`;  // Ensure proper percentage formatting
                    }}
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <RechartsLegend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Display the filtered reports */}
        <table className="w-full border-collapse border border-gray-300">
          <thead>
            <tr className="bg-gray-800 text-white">
              <th className="p-2 border">Report ID</th>
              <th className="p-2 border">Report Type</th>
              <th className="p-2 border">Date</th>
              <th className="p-2 border">Status</th>
            </tr>
          </thead>
          <tbody>
            {filteredReports.map((report) => (
              <tr key={report.id} className="text-center border">
                <td className="p-2 border">{report.id}</td>
                <td className="p-2 border">{report.type}</td>
                <td className="p-2 border">{report.date}</td>
                <td className={`p-2 border ${getStatusClass(report.status)}`}>
                  {report.status}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
