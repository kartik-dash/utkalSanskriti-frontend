import { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { createUser, fetchUserData } from "../redux/thunks/userThunks";

const UserManagement = () => {
  const dispatch = useDispatch();
  const [role, setRole] = useState("");
  const [isEditMode, setIsEditMode] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const usersPerPage = 5; // Fixed number of users per page

  useEffect(() => {
    const userRole = sessionStorage.getItem("role");
    setRole(userRole);
  }, []);

  useEffect(() => {
    const token = sessionStorage.getItem("token");
    if (token) dispatch(fetchUserData());
  }, [dispatch]);

  // Fetch users from Redux state
  const userData = useSelector((state) => state.user?.users);
  console.log("Fetched User Data:", userData);

  // Ensure usersCreatedByThisUser is an array
  const users = userData?.usersCreatedByThisUser ?? [];
  
  const { loading, error } = useSelector((state) => state.user || {});

  console.log("Users List:", users);

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    department: "",
    role: "",
    contactNumber: "",
    password: "",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value.toLowerCase());
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Dispatch createUser and wait for the result
    const resultAction = await dispatch(createUser(formData));
  
    if (createUser.fulfilled.match(resultAction)) {
      // Dispatch fetchUserData to refresh the user list
      dispatch(fetchUserData());
    }
    
    resetForm();
  };
  const resetForm = () => {
    setFormData({
      firstName: "",
      lastName: "",
      email: "",
      department: "",
      role: "",
      contactNumber: "",
      password: "",
    });
  };

  const handleDelete = (userId) => {
    console.log("Delete function should call API to remove user with ID:", userId);
    // Dispatch delete action if implemented in Redux
  };

  const handleEdit = (user) => {
    setFormData(user);
    setIsEditMode(true);
  };

  const indexOfLastUser = currentPage * usersPerPage;
  const indexOfFirstUser = indexOfLastUser - usersPerPage;

  const filteredUsers = users.filter((user) =>
    user.name?.toLowerCase().includes(searchQuery) ||
    user.role?.toLowerCase().includes(searchQuery)
  );

  const currentUsers = filteredUsers.slice(indexOfFirstUser, indexOfLastUser);
  const totalPages = Math.ceil(filteredUsers.length / usersPerPage);

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">{isEditMode ? "Edit User" : "Create User"}</h2>
      <form onSubmit={handleSubmit} className="mb-6 space-y-4">
        <div className="grid grid-cols-3 gap-4">
          {["firstName", "lastName", "email", "department", "role", "contactNumber", "password"].map((field) => (
            <div key={field} className="mb-4">
              <label className="block font-medium capitalize">{field.replace(/([A-Z])/g, " $1")}</label>
              <input
                type={field === "password" ? "password" : "text"}
                name={field}
                value={formData[field]}
                onChange={handleChange}
                placeholder={field}
                className="border p-2 w-full"
                required
              />
            </div>
          ))}
        </div>
        <button type="submit" className="bg-blue-500 text-white p-2 rounded w-30">
          {isEditMode ? "Update User" : "Add User"}
        </button>
      </form>

      <input
        type="text"
        placeholder="Search users..."
        value={searchQuery}
        onChange={handleSearchChange}
        className="border p-2 w-70 mb-4"
      />

      {loading ? (
        <p>Loading users...</p>
      ) : error ? (
        <p className="text-red-500">
          Error: {error.message ? error.message : "An unknown error occurred."}
        </p>
      ) : (
        <>
          <table className="w-full border-collapse border border-gray-300">
            <thead>
              <tr className="bg-gray-200">
                {["ID", "Name", "Role", "Created By", "Actions"].map((heading) => (
                  <th key={heading} className="border p-2">{heading}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {currentUsers.length > 0 ? (
                currentUsers.map((user) => (
                  <tr key={user.userId} className="text-center">
                    <td className="border p-2">{user.userId}</td>
                    <td className="border p-2">{user.name}</td>
                    <td className="border p-2">{user.role}</td>
                    <td className="border p-2">{userData.name || "Unknown"}</td>
                    <td className="border p-2">
                      <button onClick={() => handleEdit(user)} className="bg-yellow-500 text-white p-2 rounded mr-2">Edit</button>
                      <button onClick={() => handleDelete(user.userId)} className="bg-red-500 text-white p-2 rounded">Delete</button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="5" className="border p-2 text-center text-gray-500">No users found</td>
                </tr>
              )}
            </tbody>
          </table>

          <div className="mt-4 flex justify-center gap-4">
            <button
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(currentPage - 1)}
              className="bg-gray-300 text-gray-700 p-2 rounded"
            >
              Previous
            </button>
            <span>Page {currentPage} of {totalPages}</span>
            <button
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage(currentPage + 1)}
              className="bg-gray-300 text-gray-700 p-2 rounded"
            >
              Next
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default UserManagement;
