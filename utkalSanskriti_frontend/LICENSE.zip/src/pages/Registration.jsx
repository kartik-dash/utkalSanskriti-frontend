import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useForm } from 'react-hook-form';
import { createUser } from "../redux/thunks/userThunks"; // import your thunk

const RegistrationPage = () => {
  const dispatch = useDispatch();
  const { loading, error, status } = useSelector((state) => state.user); // Extract loading, error, and status from redux store
  const { register, handleSubmit, formState: { errors } } = useForm();
  
  const [flashMessage, setFlashMessage] = useState(""); // For storing flash message

  // Display flash message if there is any error or success
  useEffect(() => {
    if (error) {
      const errorMessage = error?.message || "Something went wrong. Please try again.";
      setFlashMessage(errorMessage);
      setTimeout(() => setFlashMessage(""), 3000); // Clear message after 3 seconds
    }

    if (status === 'succeeded') {
      setFlashMessage("Registration successful!"); // Success message
      setTimeout(() => {
        // You can navigate to another page or clear the form here
      }, 3000);
    }
  }, [error, status]);

  const onSubmit = (data) => {
    console.log("Form Data Submitted: ", data);
    dispatch(createUser(data)); // Dispatch the action with the form data
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="w-full max-w-lg p-6 bg-white rounded-lg shadow-lg">
        <h2 className="text-2xl font-bold text-center text-gray-700 mb-6">User Registration</h2>
        <form onSubmit={handleSubmit(onSubmit)} className="grid grid-cols-1 md:grid-cols-2 gap-4">
          
          {/* Full Name Field */}
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-600">Full Name</label>
            <input
              id="name"
              type="text"
              {...register('name', { required: 'Full Name is required' })}
              className={`w-full mt-2 p-2 border rounded-md ${errors.name ? 'border-red-500' : 'border-gray-300'}`}
            />
            {errors.name && <p className="text-red-500 text-sm">{errors.name.message}</p>}
          </div>

          {/* Email Field */}
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-600">Email</label>
            <input
              id="email"
              type="email"
              {...register('email', { 
                required: 'Email is required',
                pattern: {
                  value: /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/,
                  message: 'Invalid email address',
                }
              })}
              className={`w-full mt-2 p-2 border rounded-md ${errors.email ? 'border-red-500' : 'border-gray-300'}`}
            />
            {errors.email && <p className="text-red-500 text-sm">{errors.email.message}</p>}
          </div>

          {/* Phone Number Field */}
          <div>
            <label htmlFor="phone" className="block text-sm font-medium text-gray-600">Phone Number</label>
            <input
              id="phone"
              type="tel"
              {...register('contactNumber', {
                required: 'Phone number is required',
                pattern: {
                  value: /^[0-9]{10}$/,
                  message: 'Phone number must be 10 digits',
                }
              })}
              className={`w-full mt-2 p-2 border rounded-md ${errors.phone ? 'border-red-500' : 'border-gray-300'}`}
            />
            {errors.phone && <p className="text-red-500 text-sm">{errors.phone.message}</p>}
          </div>

          {/* Designation Dropdown */}
          <div>
            <label htmlFor="designation" className="block text-sm font-medium text-gray-600">Designation</label>
            <select
              id="designation"
              {...register('role', { required: 'Please select your designation' })}
              className={`w-full mt-2 p-2 border rounded-md ${errors.designation ? 'border-red-500' : 'border-gray-300'}`}
            >
              <option value="">Select your designation</option>
              <option value="CLIENT">Client</option>
              <option value="ADMIN">Admin</option>
            </select>
            {errors.designation && <p className="text-red-500 text-sm">{errors.designation.message}</p>}
          </div>

          {/* Password Field */}
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-gray-600">Password</label>
            <input
              id="password"
              type="password"
              {...register('password', { 
                required: 'Password is required',
                minLength: { value: 6, message: 'Password must be at least 6 characters long' }
              })}
              className={`w-full mt-2 p-2 border rounded-md ${errors.password ? 'border-red-500' : 'border-gray-300'}`}
            />
            {errors.password && <p className="text-red-500 text-sm">{errors.password.message}</p>}
          </div>

          {/* Address Field */}
          <div className="col-span-2">
            <label htmlFor="address" className="block text-sm font-medium text-gray-600">Address</label>
            <textarea
              id="address"
              {...register('address', { required: 'Address is required' })}
              rows="4"
              className={`w-full mt-2 p-2 border rounded-md ${errors.address ? 'border-red-500' : 'border-gray-300'}`}
            ></textarea>
            {errors.address && <p className="text-red-500 text-sm">{errors.address.message}</p>}
          </div>

          {/* Submit Button */}
          <div className="col-span-2">
            <button type="submit" className="w-full mt-4 p-2 bg-blue-500 text-white rounded-md hover:bg-blue-600" disabled={loading}>
              {loading ? "Registering..." : "Register"}
            </button>
          </div>
        </form>

        {flashMessage && (
          <div className="mt-4 text-center text-sm text-red-500">
            {flashMessage}
          </div>
        )}
      </div>
    </div>
  );
};

export default RegistrationPage;
