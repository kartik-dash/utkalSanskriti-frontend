import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { loginUser } from "../redux/thunks/authThunks"; // import your thunk
import { useNavigate } from "react-router-dom";

const Signin = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const { loading, error, status, role } = useSelector((state) => state.auth); // Extract loading, error, and status states
  // const { role } = useSelector((state) => state.auth);

  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const [flashMessage, setFlashMessage] = useState(""); // For storing flash message

  // Redirect to dashboard after successful login
  useEffect(() => {
    if (status === 'succeeded') {
      if (role === 'MASTER_ADMIN') {
        navigate('/dashboard');  // Redirect to Admin Dashboard
      } else if (role === 'USER') {
        navigate('/dashboard');  // Redirect to Client Dashboard
      } else if (role === 'TOP_LEVEL_MANAGEMENT') {
        navigate('/dashboard');  // Redirect to Manager Dashboard
      }
      else if (role === 'MID_LEVEL_MANAGEMENT') {
        navigate('/dashboard');  // Redirect to Manager Dashboard
      }
      else if (role === 'LOWER_LEVEL_MANAGEMENT') {
        navigate('/dashboard');  // Redirect to Manager Dashboard
      }
      else if (role === 'EXUCUTIVE_MANAGEMENT') {
        navigate('/dashboard');  // Redirect to Manager Dashboard
      }
      
    }
  }, [status, navigate]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(loginUser(formData));
     // Dispatch the signIn action with form data
  };

  // Display flash message if there is any error or success
  useEffect(() => {
    if (error) {
      // Check if the error is an object and extract the error message
      const errorMessage = error?.message || "Something went wrong. Please try again.";
      setFlashMessage(errorMessage);
      setTimeout(() => setFlashMessage(""), 3000); // Clear message after 3 seconds
    }
  }, [error]);

  return (
    <section className="bg-gray-1 py-20 dark:bg-dark lg:py-[120px]">
      <div className="container mx-auto">
        <div className="-mx-4 flex flex-wrap">
          <div className="w-full px-4">
            <div className="relative mx-auto max-w-[525px] overflow-hidden rounded-lg bg-white px-10 py-16 text-center dark:bg-dark-2 sm:px-12 md:px-[60px]">
              <div className="mb-10 text-center md:mb-16">
                <a href="#" className="mx-auto inline-block max-w-[160px]" onClick={(e) => e.preventDefault()}>
                  <img
                    src="https://cdn.tailgrids.com/2.0/image/assets/images/logo/logo-primary.svg"
                    alt="logo"
                  />
                </a>
              </div>

              {loading ? (
                <div className="flex justify-center items-center">
                  <div className="spinner-border animate-spin inline-block w-8 h-8 border-4 rounded-full border-t-transparent border-primary" role="status">
                    <span className="visually-hidden">Loading...</span>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit}>
                  <InputBox
                    type="email"
                    name="email"
                    placeholder="Email"
                    value={formData.email}
                    onChange={handleChange}
                  />
                  <InputBox
                    type="password"
                    name="password"
                    placeholder="Password"
                    value={formData.password}
                    onChange={handleChange}
                  />
                  {flashMessage && (
                    <div className="text-red-500 mb-4 text-center">{flashMessage}</div>
                  )}
                  <div className="mb-10">
                    <input
                      type="submit"
                      value={loading ? "Signing In..." : "Sign In"}
                      className="w-full cursor-pointer rounded-md border border-primary bg-primary px-5 py-3 text-base font-medium text-white transition hover:bg-opacity-90"
                      disabled={loading}
                    />
                  </div>
                </form>
              )}

              <p className="mb-6 text-base text-secondary-color dark:text-dark-7">Connect With</p>
              <ul className="-mx-2 mb-12 flex justify-between">
                {/* Social buttons here */}
              </ul>

              <a
                href="#"
                className="mb-2 inline-block text-base text-dark hover:text-primary hover:underline dark:text-white"
                onClick={(e) => e.preventDefault()}
              >
                Forget Password?
              </a>
              <p className="text-base text-body-color dark:text-dark-6">
                <span className="pr-0.5">Not a member yet?</span>
                <a href="#" className="text-primary hover:underline" onClick={(e) => e.preventDefault()}>
                  Sign Up
                </a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const InputBox = ({ type, placeholder, name, value, onChange }) => {
  return (
    <div className="mb-6">
      <input
        type={type}
        placeholder={placeholder}
        name={name}
        value={value}
        onChange={onChange}
        className="w-full rounded-md border border-stroke bg-transparent px-5 py-3 text-base text-body-color outline-none focus:border-primary focus-visible:shadow-none dark:border-dark-3 dark:text-white"
      />
    </div>
  );
};

export default Signin;
