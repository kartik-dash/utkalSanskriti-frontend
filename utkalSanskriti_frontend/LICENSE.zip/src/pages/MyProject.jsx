import React, { useState } from 'react';

const MyProject = () => {
    const [selectedAction, setSelectedAction] = useState(null);
    const [showTextarea, setShowTextarea] = useState(false);
    const [showPopup, setShowPopup] = useState(false);
    const [text, setText] = useState('');
    const [file, setFile] = useState(null);

    const buttonStyle = {
        padding: '10px 20px',
        fontSize: '16px',
        color: 'white',
        border: '1px solid #ddd',
        borderRadius: '5px',
        cursor: 'pointer',
        transition: 'background-color 0.3s ease',
    };

    const formStyle = {
        justifyContent: 'center',
        alignItems: 'center',
    };

    const handleButtonClick = (action) => {
        setSelectedAction(action);
        
        if (action === 'Error') {
            setShowPopup(true); 
        } else {
            setShowTextarea(true);
        }
    };

    const handleClosePopup = () => {
        setShowPopup(false);
        setSelectedAction(null);
        setText('');
        setFile(null);
    };

    const handleTextChange = (e) => {
        setText(e.target.value);
    };

    const handleFileChange = (e) => {
        setFile(e.target.files[0]);
    };

    const handleSubmit = () => {
        alert(`Submitted: ${selectedAction}\nText: ${text}\nFile: ${file ? file.name : 'No file uploaded'}`);
        setText('');
        setFile(null);
        setShowPopup(false);
        setShowTextarea(false);
    };

    return (
        <form onSubmit={(e) => e.preventDefault()} style={formStyle}>
            <div>
                <table style={{ width: '80%', borderCollapse: 'collapse', margin: 'auto', border: '1px solid #ddd' }}>
                    <thead>
                        <tr>
                            <th style={{ padding: '8px', backgroundColor: '#f4f4f4', border: '1px solid #ddd' }}>Id</th>
                            <th style={{ padding: '8px', backgroundColor: '#f4f4f4', border: '1px solid #ddd' }}>Project Name</th>
                            <th style={{ padding: '8px', backgroundColor: '#f4f4f4', border: '1px solid #ddd' }}>Assigned Work</th>
                            <th style={{ padding: '8px', backgroundColor: '#f4f4f4', border: '1px solid #ddd' }}>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td style={{ padding: '8px', backgroundColor: '#e9f5e9', border: '1px solid #ddd' }}>1</td>
                            <td style={{ padding: '8px', backgroundColor: '#e9f5e9', border: '1px solid #ddd' }}>Grand Spax</td>
                            <td style={{ padding: '8px', backgroundColor: '#e9f5e9', border: '1px solid #ddd' }}>About Us Page</td>
                            <td style={{ padding: '8px', backgroundColor: '#e9f5e9', border: '1px solid #ddd' }}>
                                <div style={{ display: 'flex', gap: '10px' }}>
                                    <button type="button" style={{ ...buttonStyle, backgroundColor: '#4CAF50' }} onClick={() => handleButtonClick('Submit')}>
                                        Submit
                                    </button>
                                    <button type="button" style={{ ...buttonStyle, backgroundColor: '#f44336' }} onClick={() => handleButtonClick('Error')}>
                                        Error
                                    </button>
                                    <button type="button" style={{ ...buttonStyle, backgroundColor: '#ff9800' }} onClick={() => handleButtonClick('Under Progress')}>
                                        Under Progress
                                    </button>
                                    <button type="button" style={{ ...buttonStyle, backgroundColor: '#2196F3' }} onClick={() => handleButtonClick('Hold')}>
                                        Hold
                                    </button>
                                    <button type="button" style={{ ...buttonStyle, backgroundColor: '#9E9E9E' }} onClick={() => handleButtonClick('Pending')}>
                                        Pending
                                    </button>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>

                {/* Show textarea for non-error actions */}
                {showTextarea && selectedAction && selectedAction !== 'Error' && (
                    <div style={{ marginTop: '20px', textAlign: 'center' }}>
                        <h3>{selectedAction} Details</h3>
                        <textarea
                            style={{ width: '30%', height: '100px', padding: '10px', borderRadius: '5px', border: '1px solid #ddd' }}
                            placeholder={`Enter details for ${selectedAction}...`}
                            value={text}
                            onChange={handleTextChange}
                        />
                    </div>
                )}

                {/* Error Popup */}
                {showPopup && (
                    <div style={{
                        position: 'fixed',
                        left: '50%',
                        top: '20%',
                        transform: 'translateX(-50%)',
                        backgroundColor: '#fff',
                        color: '#000',
                        width: '30%',
                        padding: '15px',
                        borderRadius: '5px',
                        boxShadow: '0px 0px 10px rgba(0,0,0,0.2)',
                        zIndex: 1000
                    }}>
                        <div style={{ textAlign: 'center' }}>
                            <h3>{selectedAction} Details</h3>
                            <textarea
                                style={{
                                    width: '80%',
                                    height: '100px',
                                    padding: '10px',
                                    borderRadius: '5px',
                                    border: '1px solid #ddd',
                                    display: 'block',
                                    margin: '10px auto'
                                }}
                                placeholder={`Enter details for ${selectedAction}...`}
                                value={text}
                                onChange={handleTextChange}
                            />
                            <input
                                type="file"
                                style={{ display: 'block', margin: '10px auto' }}
                                onChange={handleFileChange}
                            />
                            <button
                                type="button"
                                style={{ ...buttonStyle, backgroundColor: '#4CAF50', margin: '10px 5px 0px 0px' }}
                                onClick={handleSubmit}
                            >
                                Submit
                            </button>
                            <button
                                onClick={handleClosePopup}
                                style={{
                                    backgroundColor: '#fff',
                                    color: 'red',
                                    border: '1px solid red',
                                    padding: '5px 10px',
                                    cursor: 'pointer',
                                    marginTop: '10px'
                                }}
                            >
                                Close
                            </button>
                        </div>
                    </div>
                )}
            </div>
        </form>
    );
};

export default MyProject;
