import React, { useState } from "react";
import {
  Home,
  User,
  Settings,
  LogOut,
  BarChart,
  ChevronDown,
  ChevronRight,
  Layout,
  DatabaseZap,
  Users,
  MonitorCog,
  CircleHelp,
  FolderOpenDot,
  ReceiptText,
  ChartColumnIncreasing,
  
} from "lucide-react";

const Sidebar = ({ isOpen, setIsSidebarOpen, role }) => {
  const [openMenus, setOpenMenus] = useState({});
  const [activeMenuItem, setActiveMenuItem] = useState(null); // Track active menu item

  const toggleSubMenu = (label) => {
    setOpenMenus((prev) => ({ ...prev, [label]: !prev[label] }));
  };

  const handleMenuItemClick = (label) => {
    setActiveMenuItem(label); // Set the active menu item
  };

  let menuItems = [];

  if (role === "MASTER_ADMIN") {
    menuItems = [
      { path: "/dashboard", label: "Dashboard", icon: <Home size={24} /> },
      { path: "/user-management", label: "Create Top Level", icon: <User size={24} /> },


      {
        label: "Reports",
        icon: <BarChart size={24} />,
        subMenu: [
          {
            label: "Create Report",
            subMenu: [
              { path: "/create-report/usage/template", label: "From Template" },
              { path: "/create-report/usage/CustomReport", label: "Custom Report" }
            ]
          },
          {
            label: "Report Library",
            subMenu: [
              { path: "/report-library/AllReports", label: "All Reports" },
              { path: "/report-library/MyReports", label: "My Reports" },
              { path: "/report-library/SharedWithMe", label: "Shared with Me" },
              { path: "/report-library/ArchivedReports", label: "Archived Reports" }
            ]
          },
          {
            label: "Scheduled Reports",
            subMenu: [
              { path: "/report-library/view-schedule", label: "View Schedule" },
              { path: "/report-library/manage-schedules", label: "Manage Schedules" }
            ]
          },
        ]
      },
      {
        label: "Templates",
        icon: <Layout size={24} />,
        subMenu: [
          {
            label: "Manage Templates",
            subMenu: [
              { path: "/manage-templates/view-all-templates", label: "View All Templates" },
              { path: "/manage-templates/create-new-template", label: "Create New Template" },
              { path: "/manage-templates/edit-existing-templates", label: "Edit Existing Templates" },
              { path: "/manage-templates/delete-templates", label: "Delete Templates" }
            ]
          },
          {
            label: "Import/Export Templates",
            subMenu: [
              { path: "/manage-templates/Import Template", label: "Import Template" },
              { path: "/manage-templates/Export Template", label: "Export Template" }
            ]
          },
        ],
      },
      {
        label: "Data Sources",
        icon: <DatabaseZap size={24} />,
        subMenu: [
          {
            label: "Manage Data Connections",
            subMenu: [
              { path: "/manage-data-connections/add-new-data-source", label: "Add New Data Source" },
              { path: "/manage-data-connections/edit-data-source", label: "Edit Data Source" },
              { path: "/manage-data-connections/delete-data-source", label: "Delete Data Source" },

            ]
          },
          {
            label: "Data Source Settings",
            subMenu: [
              { path: "/data-source-settings/connection-parameters", label: "Connection Parameters" },
              { path: "/data-source-settings/authentication-methods", label: "Authentication Methods" }
            ]
          },
        ],
      },
      {
        label: "User Management",
        icon: <Users size={24} />,
        subMenu: [
          {
            label: "User Accounts",
            subMenu: [
              { path: "/user-accounts/view-all-users", label: "View All Users" },
              { path: "/user-accounts/add-new-user", label: "Add New User" },
              { path: "/user-accounts/edit-user-details", label: "Edit User Details" },
              { path: "/user-accounts/deactivate-user", label: "Deactivate User" }
            ]
          },
          {
            label: "Roles and Permissions",
            subMenu: [
              { path: "/roles-and-permissions/define-roles", label: "Define Roles" },
              { path: "/roles-and-permissions/assign-permissions", label: "Assign Permissions" },
              { path: "/roles-and-permissions/audit-user-activities", label: "Audit User Activities" },
            ]

          },
        ],
      },
      {
        label: "Settings",
        icon: <MonitorCog size={24} />,
        subMenu: [
          {
            label: "General Settings",
            subMenu: [
              { path: "/general-settings/portal-configuration", label: "Portal Configuration" },
              { path: "/general-settings/notification-preferences", label: "Notification Preferences" },
            ]
          },
          {
            label: "Security Settings",
            subMenu: [
              { path: "/security-settings/password-policies", label: "Password Policies" },
              { path: "/security-settings/two-Factor-authentication", label: "Two-Factor Authentication" },
              { path: "/security-settings/access-logs", label: "Access Logs" },
            ]
          },
        ],
      },
      {
        label: "Help & Support",
        icon: <CircleHelp size={24} />,
        subMenu: [
          {
            label: "Documentation",
            subMenu: [
              { path: "/documentation/user-guides", label: "User Guides" },
              { path: "/Documentation/faqs", label: "FAQs" },

            ]
          },
          {
            label: "Contact Support",
            subMenu: [
              { path: "/contact-support/submit-a-ticket", label: "Submit a Ticket" },
              { path: "/contact-support/livechat", label: "Live Chat" },
            ]
          },
          {
            label: "About",
            subMenu: [
              { path: "/about/version-information", label: "Version Information" },
              { path: "/about/release-notes", label: "Release Notes" },
            ]
          },
        ],
      },
      {
        label: "Reports",
        icon: <BarChart size={24} />,
        subMenu: [
          { path: "/reports/sales", label: "Sales Reports" },
          { path: "/reports/analytics", label: "Analytics Reports" },
        ],
      },
      { path: "/profile", label: "Profile", icon: <User size={24} /> },
      { path: "/registration", label: "Registration", icon: <Settings size={24} /> },
    ];
  }
  if (role === "TOP_LEVEL_MANAGEMENT") {
    menuItems = [
      { path: "/dashboard", label: "Dashboard", icon: <Home size={24} /> },
      { path: "/profile", label: "Profile", icon: <User size={24} /> },
      { path: "/user-management", label: "Create Mid Level", icon: <FolderOpenDot size={24} /> },
      { path: "/Userreport", label: "Report", icon: <BarChart size={24} /> },
      { path: "/MyProject", label: "MyProject", icon: <FolderOpenDot size={24} /> },
      { path: "/AllProject", label: "All Project", icon: <ReceiptText size={24} /> },
      { path: "/ProjectStatus", label: "Project Status", icon: <ChartColumnIncreasing size={24} /> },


    ];
  }
  if (role === "MID_LEVEL_MANAGEMENT") {
    menuItems = [
      { path: "/dashboard", label: "Dashboard", icon: <Home size={24} /> },
      { path: "/profile", label: "Profile", icon: <User size={24} /> },
      { path: "/user-management", label: "Register Lower Level", icon: <FolderOpenDot size={24} /> },
      { path: "/Userreport", label: "Report", icon: <BarChart size={24} /> },
      { path: "/MyProject", label: "MyProject", icon: <FolderOpenDot size={24} /> },
      { path: "/AllProject", label: "All Project", icon: <ReceiptText size={24} /> },
      { path: "/ProjectStatus", label: "Project Status", icon: <ChartColumnIncreasing size={24} /> },

    ];
  }
  if (role === "LOWER_LEVEL_MANAGEMENT") {
    menuItems = [
      { path: "/dashboard", label: "Dashboard", icon: <Home size={24} /> },
      { path: "/profile", label: "Profile", icon: <User size={24} /> },
      { path: "/user-management", label: "Create Executive Management", icon: <FolderOpenDot size={24} /> },
      { path: "/Userreport", label: "Report", icon: <BarChart size={24} /> },
      { path: "/MyProject", label: "My Project", icon: <FolderOpenDot size={24} /> },
      { path: "/AllProject", label: "All Project", icon: <ReceiptText size={24} /> },
      { path: "/ProjectStatus", label: "Project Status", icon: <ChartColumnIncreasing size={24} /> },
    ];
  }
  if (role === "EXUCUTIVE_MANAGEMENT") {
    menuItems = [
      { path: "/dashboard", label: "Dashboard", icon: <Home size={24} /> },
      { path: "/profile", label: "Profile", icon: <User size={24} /> },
      { path: "/user-management", label: "Executive CreateUser", icon: <FolderOpenDot size={24} /> },
      { path: "/Userreport", label: "Report", icon: <BarChart size={24} /> },
      { path: "/MyProject", label: "My Project", icon: <FolderOpenDot size={24} /> },
      { path: "/AllProject", label: "All Project", icon: <ReceiptText size={24} /> },
      { path: "/ProjectStatus", label: "Project Status", icon: <ChartColumnIncreasing size={24} /> },
    ];
  }
  if (role === "USER") {
    menuItems = [
      { path: "/UserDashboard", label: "Dashboard", icon: <Home size={24} /> },
      { path: "/profile", label: "Profile", icon: <User size={24} /> },
      { path: "/MyProject", label: "My Project", icon: <FolderOpenDot size={24} /> },
      { path: "/Userreport", label: "Report", icon: <BarChart size={24} /> },

    ];
  }
  return (
    <aside
      className={`transition-all duration-300 bg-gray-800 text-white min-h-screen fixed top-0 left-0 ${isOpen ? "w-64" : "w-16"}`}
    >
      <div className="flex flex-col h-full">
        {/* Logo */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          {/* Show role-based titles */}
          {role === "MASTER_ADMIN" && (
            <span className="text-xl font-bold">Master Admin</span>
          )}
          {role === "TOP_LEVEL_MANAGEMENT" && (
            <span className="text-xl font-bold">Top_Level_Management</span>
          )}
          {role === "MID_LEVEL_MANAGEMENT" && (
            <span className="text-xl font-bold">Mid_Level_Management</span>
          )}
          {role === "LOWER_LEVEL_MANAGEMENT" && (
            <span className="text-xl font-bold">Lower_Level_Management</span>
          )}
          {role === "EXUCUTIVE_MANAGEMENT" && (
            <span className="text-xl font-bold">Exucutive_Management</span>
          )}
          {role === "USER" && (
            <span className="text-xl font-bold">User</span>
          )}
        </div>
        {/* Navigation */}
        <nav className="flex-1 px-4 py-6 h-screen overflow-y-auto">
          {menuItems.map((item, index) => (
            <div key={index} className="mb-2">
              {item.subMenu ? (
                <div>
                  <button
                    className={`flex items-center justify-between w-full p-2 space-x-4 text-gray-300 hover:bg-gray-700 rounded-lg ${activeMenuItem === item.label ? "bg-gray-700" : ""
                      }`}
                    onClick={() => {
                      toggleSubMenu(item.label);
                      handleMenuItemClick(item.label);
                    }}
                  >
                    <div className="flex items-center space-x-4">
                      {item.icon}
                      <span className={`${isOpen ? "" : "hidden"}`}>{item.label}</span>
                    </div>
                    {isOpen && (openMenus[item.label] ? <ChevronDown size={20} /> : <ChevronRight size={20} />)}
                  </button>
                  {
                    openMenus[item.label] && (
                      <div className="ml-6 mt-2" >
                        {
                          item.subMenu.map((subItem, subIndex) => (
                            <div key={subIndex} >
                              {
                                subItem.subMenu ? (
                                  <div>
                                    {/* Create Report submenu button */}
                                    < button
                                      className="flex items-center justify-between w-full p-2 text-gray-400 hover:bg-gray-600 rounded-lg"
                                      onClick={() => toggleSubMenu(subItem.label)
                                      }
                                    >
                                      <span>{subItem.label} </span>
                                      {openMenus[subItem.label] ? <ChevronDown size={20} /> : <ChevronRight size={20} />}
                                    </button>

                                    {/* Nested submenu (From Template) */}
                                    {
                                      openMenus[subItem.label] && (
                                        <div className="ml-4 mt-2" >
                                          {
                                            subItem.subMenu.map((nestedSub, nestedIndex) => (
                                              <a
                                                href={nestedSub.path}
                                                key={nestedIndex}
                                                className="block p-2 text-gray-400 hover:text-white hover:bg-gray-600 rounded-lg"
                                              >
                                                {nestedSub.label}
                                              </a>
                                            ))
                                          }
                                        </div>
                                      )
                                    }
                                  </div>
                                ) : (
                                  <a
                                    href={subItem.path}
                                    className="block p-2 text-gray-400 hover:text-white hover:bg-gray-600 rounded-lg"
                                  >
                                    {subItem.label}
                                  </a>
                                )
                              }
                            </div>
                          ))}
                      </div>
                    )}
                </div>
              ) : (
                <a
                  href={item.path}
                  className={`flex items-center p-2 space-x-4 text-gray-300 hover:bg-gray-700 rounded-lg ${activeMenuItem === item.label ? "bg-gray-700" : ""
                    }`}
                  onClick={() => handleMenuItemClick(item.label)}
                >
                  {item.icon}
                  <span className={`${isOpen ? "" : "hidden"}`}>{item.label}</span>
                </a>
              )}
            </div>
          ))}
        </nav>
        {/* Logout */}
        <div className="p-4">
          <a
            href="#"
            className="flex items-center p-2 space-x-4 text-red-500 hover:bg-gray-700 rounded-lg"
          >
            <LogOut size={24} />
            <span className={`${isOpen ? "" : "hidden"}`}>Logout</span>
          </a>
        </div>
      </div>
    </aside>
  );
};
export default Sidebar;
