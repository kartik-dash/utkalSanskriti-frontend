/*eslint-disable*/
import React from "react";
import { Link } from "react-router-dom";
import logo from "../../assets/img/logo.png";

export default function Navbar(props) {
  const [navbarOpen, setNavbarOpen] = React.useState(false);

  return (
    <>
      <nav className="top-0 fixed z-50 w-full flex flex-wrap items-center justify-between px-0 py-3 navbar-expand-lg bg-white shadow">
        <div className="container px-0 mx-0 flex flex-wrap items-center justify-between">
          {/* Logo Section */}
          <div className="w-full relative flex justify-between lg:w-auto lg:static lg:block lg:justify-start lg:items-start">
            <Link to="/">
              <img src={logo} alt="logo" className="w-full h-16" />
            </Link>
            <button
              className="cursor-pointer text-xl leading-none px-3 py-1 border border-solid border-transparent rounded bg-transparent block lg:hidden outline-none focus:outline-none"
              type="button"
              onClick={() => setNavbarOpen(!navbarOpen)}
            >
              <i className="fas fa-bars"></i>
            </button>
          </div>

          {/* Navigation Links */}
          <div
            className={
              "lg:flex flex-grow items-center bg-white lg:bg-opacity-0 lg:shadow-none lg:content-end lg:mr-4" +
              (navbarOpen ? " block" : " hidden")
            }
            id="example-navbar-warning"
          >
            <ul className="flex flex-col lg:flex-row list-none lg:ml-auto">
              <li className="flex items-center px-4">
                <Link to="/">Home</Link>
              </li>
              <li className="flex items-center px-4 cursor-pointer">
                <Link to="/about">About</Link>
              </li>
              <li className="flex items-center px-4">
                <Link to="/contact">Contact Us</Link>
              </li>
              <li className="flex items-center px-4">
                <Link to="/services">Services</Link>
              </li>
              <li className="flex items-center px-4">
                <Link to="/login">
                  <button
                    className="bg-red-500 text-white active:bg-lightBlue-600 text-xs font-bold uppercase px-4 py-2 rounded shadow hover:shadow-lg outline-none focus:outline-none lg:mr-1 lg:mb-0 ml-3 mb-3 ease-linear transition-all duration-150"
                    type="button"
                  >
                    Login
                  </button>
                </Link>
              </li>
              <li className="flex items-center px-4">
                <Link to="/registartion">
                  <button
                    className="bg-blue-500 text-white active:bg-lightBlue-600 text-xs font-bold uppercase px-4 py-2 rounded shadow hover:shadow-lg outline-none focus:outline-none lg:mr-1 lg:mb-0 ml-3 mb-3 ease-linear transition-all duration-150"
                    type="button"
                  >
                    Register
                  </button>
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </>
  );
}
