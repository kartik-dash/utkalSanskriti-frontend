import React, { useState, useRef, useEffect } from 'react';
import { Menu, X, Search, Bell, ChevronDown, LogOut } from 'lucide-react';
import { useDispatch } from 'react-redux';
import { logoutUser } from '../redux/thunks/authThunks';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';

const Header = ({ toggleSidebar, isOpen }) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [notificationDropdownOpen, setNotificationDropdownOpen] = useState(false);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  // Ref for the notification dropdown
  const notificationDropdownRef = useRef(null);

  // Handle clicks outside the notification dropdown
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        notificationDropdownRef.current &&
        !notificationDropdownRef.current.contains(event.target)
      ) {
        setNotificationDropdownOpen(false);
      }
    };

    // Add event listener
    document.addEventListener('mousedown', handleClickOutside);

    // Clean up event listener
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleLogout = () => {
    const token = sessionStorage.getItem('token');
    if (token) {
      dispatch(logoutUser(token))
        .then(() => {
          sessionStorage.clear();
          console.log('User logged out. Redirecting to /login');
          window.location.href = '/login';
        })
        .catch((error) => {
          console.error('Logout failed:', error);
        });
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 px-6 py-4 bg-white shadow-md ml-64">
      <div className="flex items-center justify-between">
        {/* Sidebar Toggle (open and close icons) */}
        <button
          onClick={toggleSidebar}
          className="text-gray-600 hover:text-gray-900 focus:outline-none lg:hidden"
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>

        {/* Search Bar */}
        <div className="relative flex items-center w-full max-w-md lg:max-w-xl">
          <span className="absolute left-3 text-gray-400">
            <Search size={20} />
          </span>
          <input
            type="text"
            placeholder="Search..."
            className="w-full pl-10 pr-4 py-2 text-sm border rounded-lg focus:outline-none focus:ring focus:ring-blue-300"
          />
        </div>

        {/* Notification and Profile */}
        <div className="flex items-center space-x-4 relative">
          {/* Notification Dropdown */}
          <div className="relative" ref={notificationDropdownRef}>
            <button
              onClick={() => setNotificationDropdownOpen(!notificationDropdownOpen)}
              className="relative text-gray-600 hover:text-gray-900 focus:outline-none"
            >
              <Bell size={24} />
              <span className="absolute top-0 right-0 h-2 w-2 bg-red-500 rounded-full"></span>
            </button>
            {notificationDropdownOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white border rounded-lg shadow-lg py-2">
                  <Link to="/Notification">
                <button className="block w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100">
                  Notification 1
                </button>
                </Link>
                <button className="block w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100">
                  Notification 2
                </button>
                <button className="block w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100">
                  Notification 3
                </button>
              </div>
            )}
          </div>
          {/* Profile Dropdown */}
          <div className="relative">
            <button
              onClick={() => setDropdownOpen(!dropdownOpen)}
              className="flex items-center focus:outline-none"
            >
              <img
                src="https://via.placeholder.com/40"
                alt="Profile"
                className="w-10 h-10 rounded-full border-2 border-blue-500"
              />
            </button>
            {dropdownOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white border rounded-lg shadow-lg py-2">
                <button className="block w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100">
                  Edit Profile
                </button>
                <button className="block w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100">
                  Settings
                </button>
                <button
                  onClick={handleLogout}
                  className="flex items-center justify-between w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100"
                >
                  Logout <LogOut size={20} className="text-gray-600" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;