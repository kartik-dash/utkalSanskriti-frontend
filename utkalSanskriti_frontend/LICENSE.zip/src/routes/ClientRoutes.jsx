import UserDashboard from '../pages/UserDashboard';
import MyProject from '../pages/MyProject';
import Profile from '../pages/Profile';
import Userreport from '../pages/Userreport';
import AllProject from '../pages/AllProject';

const ClientRoutes = [
  { path: '/UserDashboard', component: UserDashboard},
  { path: '/profile', component: Profile },
  { path: '/MyProject', component: MyProject },
  { path: '/Userreport', component: Userreport },
  { path: '/AllProject', component: AllProject}
];

export default ClientRoutes;
