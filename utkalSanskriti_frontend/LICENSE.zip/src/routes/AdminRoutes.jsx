import Dashboard from '../pages/Dashboard';
import Login from '../pages/Login';
import UserManagement from '../pages/UserManagement';
import Reports from '../pages/Reports';
import profile from '../pages/Profile';
import Regster from '../pages/Registration';
import FromTemplate from '../pages/FromTemplate';
import CustomReport from '../pages/custom-report';
import AllReports from '../pages/AllReports';
import MyReports from '../pages/MyReports';
import SharedWithMe from '../pages/Sharedwithme';
import ArchivedReports from '../pages/ArchivedReports';
import Notification from '../pages/Notification';

const AdminRoutes = [
  { path: '/dashboard', component: Dashboard },
  { path: '/login', component: Login },
  { path: '/user-management', component: UserManagement },
  { path: '/reports', component: Reports },
  { path: '/profile', component: profile },
  { path: '/registartion', component: Regster },
  { path: "/create-report/usage/template", component: FromTemplate},
  { path: "/create-report/usage/CustomReport", component: CustomReport},
  { path: "/report-library/AllReports", component: AllReports},
  { path: "/report-library/MyReports", component: MyReports},
  { path: "/report-library/SharedWithMe", component: SharedWithMe},
  { path: "/report-library/ArchivedReports", component: ArchivedReports},
  { path: '/Notification', component: Notification },
];

export default AdminRoutes;
