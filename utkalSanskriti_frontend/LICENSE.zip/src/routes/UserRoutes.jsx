import Home from '../pages/Home';
import About from '../pages/About';
import Reports from '../pages/Reports';
import Contact from '../pages/Contact';
import Regster from '../pages/Registration';
import Login from '../pages/Login';
import Notification from '../pages/Notification';

const UserRoutes = [
  { path: '/', component: Home },
  { path: '/about', component: About },
  { path: '/reports', component: Reports },
  { path: '/contact', component: Contact },
  { path: '/registartion', component: Regster },
  { path: '/login', component: Login },
  { path: '/Notification', component: Notification },
];
export default UserRoutes;
