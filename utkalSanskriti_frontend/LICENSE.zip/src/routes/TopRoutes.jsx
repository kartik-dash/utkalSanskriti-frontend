import Dashboard from '../pages/Dashboard';
import Reports from '../pages/Reports';
import UserManagement from '../pages/UserManagement';
import UserReport from '../pages/Userreport';
import MyProject from '../pages/MyProject';
import ProjectStatus from '../pages/ProjectStatus';
import AllProject from '../pages/AllProject';
import Notification from '../pages/Notification';

const TopRoutes = [
  { path: '/dashboard', component: Dashboard },
  { path: '/reports', component: Reports },
  { path: '/user-management', component: UserManagement },
  { path: '/Userreport', component: UserReport },
  { path: '/MyProject', component: MyProject },
  { path: '/ProjectStatus', component: ProjectStatus },
  { path: 'AllProject', component: AllProject},
  { path: '/Notification', component: Notification },
 

];

export default TopRoutes;
