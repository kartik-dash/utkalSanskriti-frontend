import React, { useState } from 'react';
import Sidebar from '../components/Sidebar';
import Header from '../components/Header';
import { Route, Routes } from 'react-router-dom';
import TopRoutes from '../routes/TopRoutes';
import { useSelector } from "react-redux";


const Top_Level_ManagementLayout = () => {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const role = useSelector((state) => state.auth.role);

  if (!role) {
    return <div>Loading...</div>;
  }
  const toggleSidebar = () => setSidebarOpen((prevState) => !prevState);

  return (
    <div className="flex min-h-screen pt-16">
      <Sidebar isOpen={sidebarOpen} setIsSidebarOpen={setSidebarOpen} role={role} />
      <div className="flex-grow flex flex-col ml-64">
        <Header toggleSidebar={toggleSidebar} isOpen={sidebarOpen} />
        <main className="flex-grow p-6 overflow-auto">
          <Routes>
            {TopRoutes.map((route) => (
              <Route key={route.path} path={route.path} element={<route.component />} />
            ))}
          </Routes>
        </main>
      </div>
    </div>
  );
};

export default Top_Level_ManagementLayout;
