// layouts/UserLayout.js
import React from 'react';
import Navbar from '../components/Navbar'; // Navbar component
import Footer from '../components/Footer'; // Navbar component
import { Outlet } from 'react-router-dom'; // Outlet for rendering child routes

const UserLayout = () => {
  return (
    <div className="min-h-screen bg-gray-100">
      {/* Navbar - Common for all pages in the UserLayout */}
      <Navbar />

      {/* Main content area where the child routes will be rendered */}
      <main className="flex-grow">
        <Outlet />  {/* This will render the child routes based on the active route */}
      </main>
      <Footer />
      {/* You can optionally add a Footer here */}
    </div>
  );
};

export default UserLayout;
